# Details

Date : 2021-03-09 23:38:11

Directory /mnt/d/code/e4/machelper

Total : 12 files,  280 codes, 19 comments, 80 blanks, all 379 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/main/java/com/cte4/mac/machelper/AppMain.java](/src/main/java/com/cte4/mac/machelper/AppMain.java) | Java | 6 | 0 | 2 | 8 |
| [src/main/java/com/cte4/mac/machelper/JVMHelper.java](/src/main/java/com/cte4/mac/machelper/JVMHelper.java) | Java | 10 | 1 | 5 | 16 |
| [src/main/java/com/cte4/mac/machelper/MACBaseHelper.java](/src/main/java/com/cte4/mac/machelper/MACBaseHelper.java) | Java | 18 | 7 | 8 | 33 |
| [src/main/java/com/cte4/mac/machelper/collectors/JVMCollector.java](/src/main/java/com/cte4/mac/machelper/collectors/JVMCollector.java) | Java | 66 | 0 | 12 | 78 |
| [src/main/java/com/cte4/mac/machelper/model/ReqEntity.java](/src/main/java/com/cte4/mac/machelper/model/ReqEntity.java) | Java | 18 | 0 | 4 | 22 |
| [src/main/java/com/cte4/mac/machelper/model/RespEntity.java](/src/main/java/com/cte4/mac/machelper/model/RespEntity.java) | Java | 7 | 0 | 3 | 10 |
| [src/main/java/com/cte4/mac/machelper/utils/AgentConnector.java](/src/main/java/com/cte4/mac/machelper/utils/AgentConnector.java) | Java | 47 | 7 | 10 | 64 |
| [src/main/java/com/cte4/mac/machelper/utils/AgentSettings.java](/src/main/java/com/cte4/mac/machelper/utils/AgentSettings.java) | Java | 13 | 3 | 3 | 19 |
| [src/main/java/com/cte4/mac/machelper/utils/SocketClient.java](/src/main/java/com/cte4/mac/machelper/utils/SocketClient.java) | Java | 36 | 0 | 11 | 47 |
| [src/test/java/com/cte4/mac/machelper/JVMHelperTest.java](/src/test/java/com/cte4/mac/machelper/JVMHelperTest.java) | Java | 9 | 0 | 4 | 13 |
| [src/test/java/com/cte4/mac/machelper/WebSocketTest.java](/src/test/java/com/cte4/mac/machelper/WebSocketTest.java) | Java | 42 | 1 | 16 | 59 |
| [src/test/java/com/cte4/mac/machelper/collectors/JVMCollectorTest.java](/src/test/java/com/cte4/mac/machelper/collectors/JVMCollectorTest.java) | Java | 8 | 0 | 2 | 10 |

[summary](results.md)