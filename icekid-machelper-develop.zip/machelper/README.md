# machelper

#### Brief Intro
{
MAC stands for Monitoring As Code. The purpose of this project is to reduce the efforts of building the whole monitoring environment for applications. 
MAC Helper is the component to include all monitoring helper bundles. 
MAC will leverage bytecode technology to apply the helper bundle to target application in runtime.}

#### Architecture
TODO


#### Install Guide

1.  xxxx
2.  xxxx
3.  xxxx

#### Use Guide

1.  xxxx
2.  xxxx
3.  xxxx


#### Features

1.  TODO
