# Core Component of Monitoring Sidecar
Feature List
- Detect all java processes with the given naming pattern as targets
- Weave in java agent dynamically on runtime
- Weave bytecode to the targets
- Detach bytecode from the targets