package com.cte4.mac.sidecar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
