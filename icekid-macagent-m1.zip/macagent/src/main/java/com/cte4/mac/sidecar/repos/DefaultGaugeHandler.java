package com.cte4.mac.sidecar.repos;

import com.cte4.mac.sidecar.model.MetricEntity;

public class DefaultGaugeHandler implements MetricHandlerInterface {

    @Override
    public void processMetric(MetricEntity me) {
        // TODO Auto-generated method stub
        
    }
    
}
