package com.cte4.mac.sidecar.service;

public class InvalidReqestException extends Exception {

    private static final long serialVersionUID = 1L;

    public InvalidReqestException() {
        super();
    }

    public InvalidReqestException(String message) {
        super(message);
    }

    public InvalidReqestException(Throwable cause) {
        super(cause);
    }
    
}
