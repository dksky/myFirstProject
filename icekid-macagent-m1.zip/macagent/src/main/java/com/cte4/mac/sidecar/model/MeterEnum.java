package com.cte4.mac.sidecar.model;

public enum MeterEnum {
    COUNTER, GAUGE, NOTE
}
