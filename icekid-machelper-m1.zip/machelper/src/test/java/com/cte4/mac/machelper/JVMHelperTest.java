package com.cte4.mac.machelper;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class JVMHelperTest {
    @Test
    void doSth(){
        assertTrue(true);
    }
}
