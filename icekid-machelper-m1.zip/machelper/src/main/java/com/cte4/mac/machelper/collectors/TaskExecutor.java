package com.cte4.mac.machelper.collectors;

/**
 * All data collector must implement this interface
 */
public interface TaskExecutor {
    public void execute();
}
